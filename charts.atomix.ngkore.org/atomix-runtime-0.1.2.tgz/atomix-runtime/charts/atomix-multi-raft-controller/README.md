<!--
SPDX-FileCopyrightText: 2022-present Intel Corporation
SPDX-License-Identifier: Apache-2.0
-->

## Atomix MultiRaft Storage Controller

Provides a [Helm] chart for deploying [Atomix] on [Kubernetes].

To install the chart, run `helm install` from the root:

```bash
helm install atomix-multi-raft-controller .
```

[Helm]: https://helm.sh/
[Kubernetes]: https://kubernetes.io
[Atomix]: https://atomix.io
